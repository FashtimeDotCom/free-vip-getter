from distutils.core import setup
import py2exe

setup(console=['aqy.py','aqy2.py','xl.py','yk.py'])